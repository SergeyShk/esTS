Spanish sonnets of the Diachronic Spanish Sonnet Corpus (DISCO)

Source: Ruiz Fabo P., Bermúdez Sabel H., Martínez Cantón C., Calvo Tello J.
Diachronic Spanish Sonnet Corpus (DISCO), version 5.0. Madrid: UNED, 2017-2023.
https://github.com/pruizf/disco (commit b626fefad22b2c8a0ecec8903cb6a465ebadb541).
Article: Ruiz Fabo P., Bermúdez Sabel H., Martínez Cantón C., González-Blanco E.
The Diachronic Spanish Sonnet Corpus: TEI and linked open data encoding, data
distribution, and metrical findings. Digital Scholarship in the Humanities 36
(Supplement 1), 2021, i68-i80. https://doi.org/10.1093/llc/fqaa035

Licence: DISCO is distributed under the Creative Commons Attribution 4.0
International License (https://creativecommons.org/licenses/by/4.0/), and so
is this dataset.

Changes: the TEI files of one sonnet per file are converted to JSON Lines, one
sonnet per line, with the fields id, period, author, title, country, gender,
birth, death, text, meter and rhyme. The metrical patterns (ADSO, Jumper) and
the rhyme labels (RhymeTagger) are the automatic annotation of DISCO. The years
of life are read from the biographical line of the source where DISCO took a
later year of it for the death or missed a birth or a death given alone, and
without the years after a century, which are of other people or events; one
year of a work given for both years of life is left out. The country of birth
is the one named in the place of birth of that line, where it names one (Cuba
and not Haiti for Gómez de Avellaneda). The names of the authors written with
the surname first ("Rizal, José") are written with the name first, as the rest.
The speakers of the dialogues ([Car], [POETA]) and the calls of the footnotes
at the end of a line are left out of the lines, as out of their metrical
patterns. Only the sonnets in the public domain are kept: 4259 of 4523; the
264 left out are the ones of the authors who died in 1946 or later, of the
20th-century authors with no known death, of the 19th-century authors born in
1866 or later with no known death and of the 19th-century authors with no dates
whom the dates of VIAF matched by DISCO with high confidence put after 1946.
