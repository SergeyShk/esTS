Frequency dictionary of Spanish lemmas

Derived from the Spanish corpus of Google Books Ngram, version 20200217, 1-grams
(https://storage.googleapis.com/books/ngrams/books/datasetsv3.html), licensed under
the Creative Commons Attribution 3.0 Unported License
(https://creativecommons.org/licenses/by/3.0/).

Changes: the forms tagged with a part of speech of the years 1980-2019 were
lower-cased, lemmatized by simplemma 2.0.0 and summed by lemma and part of
speech; nouns written with a capital letter in 90% of their occurrences are proper
nouns (PROPN) and keep their forms.
63090618290 words; 109178 rows with at least 0.1 occurrences per million words found in
at least 5 of the 40 years.

Columns: lemma, pos, ipm (occurrences per million words), range (years with the
lemma), dispersion (Juilland's D over the years, times 100), docs (books with the
most widespread form of the lemma).
